package com.feelfree.backend.entity.Achivement;

public enum AchievementType {

    FIRST_MOOD,
    STREAK_7,
    STREAK_30,
    BREATHING_50,
    FEEL_WALL_100,
    MEDITATION_10_HOURS,
    FIRST_POST,
    ZEN_MASTER
}

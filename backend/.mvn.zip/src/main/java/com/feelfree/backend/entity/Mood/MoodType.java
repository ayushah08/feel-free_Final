package com.feelfree.backend.entity.Mood;

public enum MoodType {
    HAPPY,
    SAD,
    NEUTRAL,
    OVERWHELMED,
    ANGRY

}
